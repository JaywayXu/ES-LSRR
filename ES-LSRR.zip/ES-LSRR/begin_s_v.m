%
%      
function bsv=begin_s_v(VC,a,s,dist)
n=size(VC,1);
bsv=cell(n,1);
for i=1:n
    route=VC{i,1};
    [arr,bs,wait,back]=begin_s(route,a,s,dist);
    bsv{i}=[bs,back];
end
end