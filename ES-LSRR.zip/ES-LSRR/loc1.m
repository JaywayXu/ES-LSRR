%
%
function [RVC,RCF]=loc1(VC,cap,demands,a,b,L,s,dist,width,alph,belta,cusnum,toRemove,D)
rfvc=VC;
removed=[];
while length(removed)<toRemove
    num=size(rfvc,1);
    index=randi([1, num], 1, 1);
    route=rfvc{index,1};
    removed=[removed route];
    route=[];
    rfvc{index,1}=route;
    rfvc=deal_VC(rfvc);
end
while ~isempty(removed)
    [fv,fviv,fvip,fvC]=greedy_inserting(removed,rfvc,L,a,b,s,dist,demands,cap);
    removed(removed==fv)=[];
    [rfvc,~]=insert(fv,fviv,fvip,fvC,rfvc,dist);
end
RVC=deal_VC(rfvc);
RCF=costFuction(RVC,a,b,s,L,dist,demands,cap,alph,belta);
end