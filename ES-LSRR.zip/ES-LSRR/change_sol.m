%
%
function [rfvc]=change_sol(VC,cap,demands,a,b,L,s,dist,cusnum,D,width,toRemove)
for num=1:2
    [removed,rfvc]=random_Remove(toRemove,VC,cusnum);
    while ~isempty(removed)
        [fv,fviv,fvip,fvC]=random_inserting(removed,rfvc,L,a,b,s,dist,demands,cap);
        removed(removed==fv)=[];
        [rfvc,~]=insert(fv,fviv,fvip,fvC,rfvc,dist);
    end
    rfvc=deal_VC(rfvc);
end
end