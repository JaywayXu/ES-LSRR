%
%      
function [cost,NV,TD]=costFun(VC,dist)
NV=size(VC,1);                      
TD=travel_distance(VC,dist);        
cost=TD;                            
end