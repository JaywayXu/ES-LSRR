%
%
function [VC,Table,cost]=init_population(i,Table,Tau,Eta,alpha,beta,gama,delta,r0,a,b,width,s,L,dist,cap,demands,alph,belta)
cusnum=size(demands,1);
for j=1:cusnum
    r=rand;
    np=next_point(i,Table,Tau,Eta,alpha,beta,gama,delta,r,r0,a,b,width,s,L,dist,cap,demands);
    Table(i,j)=np;
end
VC=decode(Table(i,:),cap,demands,a,b,L,s,dist);
cost=costFuction(VC,a,b,s,L,dist,demands,cap,alph,belta);
end