%
%
function [w,ew,ecw]=violateTW(VC,a,b,s,L,dist)
NV=size(VC,1);
w=0;
ew=zeros(NV,1);
ecw=zeros(NV,3);
bsv=begin_s_v(VC,a,s,dist);
for i=1:NV
    route=VC{i};
    bs=bsv{i};
    l_bs=length(bsv{i});
    rw=zeros(1,numel(route));
    for j=1:l_bs-1
        if bs(j)>b(route(j))
            w=w+bs(j)-b(route(j));
            ew(i,1)=ew(i,1)+bs(j)-b(route(j));
            rw(j)=bs(j)-b(route(j));
        end
    end
    if bs(end)>L
        w=w+bs(end)-L;
        ew(i,1)=ew(i,1)+bs(end)-L;
    end
    find1=find(rw>0,1,'first');
    if ~isempty(find1)
        [max_vt,max_index]=max(rw);
        ecw(i,1)=max_index;
        ecw(i,2)=route(max_index);
        ecw(i,3)=max_vt;
    end
end
end