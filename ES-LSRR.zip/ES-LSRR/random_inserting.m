%
%
function [fv,fviv,fvip,fvC]=random_inserting(removed,rfvc,L,a,b,s,dist,demands,cap )
nr=length(removed);
r_index=randi([1 nr], 1, 1);
outcome=feasi_locate(removed(r_index),rfvc,L,a,b,s,dist,demands,cap);
len=size(outcome,1);
index=randi([1 len], 1, 1);
temp=outcome(index,:);
fviv=temp(1);
fvip=temp(2);
fvC=temp(3);
fv=removed(r_index);
end