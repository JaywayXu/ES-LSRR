%
%
function [removed,rfvc]=random_Remove(toRemove,VC,cusnum)
rfvc=VC;
removed=[];
inplan=1:cusnum;
while length(removed)<toRemove
    num=length(inplan);
    index=ceil(rand*num);
    visit=inplan(index);
    inplan(inplan==visit)=[];
    removed=[removed visit];
    NV=size(rfvc,1);
    for i=1:NV
        route=rfvc{i};
        findri=find(route==removed(end),1,'first');
        if ~isempty(findri)
            route(route==removed(end))=[];
            rfvc{i}=route;
            break;
        end
    end
    rfvc=deal_VC(rfvc);
end
end