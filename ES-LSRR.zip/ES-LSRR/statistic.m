%
%
function [cost,NV,TD,vio_NV,vio_cus]=statistic(VC,a,b,s,L,dist,demands,cap,alph,belta)
NV=size(VC,1);
[cost,TD]=costFuction(VC,a,b,s,L,dist,demands,cap,alph,belta);
[vio_NV,vio_cus]=vio_sta(VC,cap,demands,a,b,L,s,dist);
end