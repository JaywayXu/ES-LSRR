%
%
function [bestVC,bestCost,VC_Set,VC_Obj]=ES_LSRR(VC_Set,VC_Obj,VC,cap,demands,a,b,L,s,dist,width,alph,belta)
SN=size(VC_Set,1);
cusnum=size(demands,1);
toRemove=ceil(0.1*cusnum);
D=10;
gen=0;
iter=1;
Iter=10000;
limit=200;
bestVC=VC;
b_cost=costFuction(bestVC,a,b,s,L,dist,demands,cap,alph,belta);
bestCost=[];
counter=zeros(SN,1);
while iter<=Iter
    for i=1:SN
        [RVC,RCF]=loc1(VC_Set{i,1},cap,demands,a,b,L,s,dist,width,alph,belta,cusnum,toRemove,D);
        RNV=size(RVC,1);
        if (RNV==VC_Obj(i,1) && RCF<VC_Obj(i,2)) || RNV<VC_Obj(i,1)
            VC_Set{i,1}=RVC;
            VC_Obj(i,1)=RNV;
            VC_Obj(i,2)=RCF;
            VC_Obj(i,3)=1/(VC_Obj(i,1)+atan(VC_Obj(i,2))/(pi/2));
            counter(i,1)=0;
            if RNV<size(bestVC,1) || (RNV==size(bestVC,1) && RCF<b_cost)
                bestVC=RVC;
                b_cost=RCF;
            end
        else
            counter(i,1)=counter(i,1)+1;
        end
        gen=gen+1;
    end
    for i=1:SN
        r_index=roulette(VC_Obj(:,3));
        for num=1:2
            [RVC,RCF]=loc2(VC_Set{r_index,1},cap,demands,a,b,L,s,dist,width,alph,belta,cusnum,toRemove,D);
            RNV=size(RVC,1);
            if (RNV==VC_Obj(r_index,1) && RCF<VC_Obj(r_index,2)) || RNV<VC_Obj(r_index,1)
                VC_Set{r_index,1}=RVC;
                VC_Obj(r_index,1)=RNV;
                VC_Obj(r_index,2)=RCF;
                VC_Obj(r_index,3)=1/(VC_Obj(r_index,1)+atan(VC_Obj(r_index,2))/(pi/2));
                counter(r_index,1)=0;
                if RNV<size(bestVC,1) || (RNV==size(bestVC,1) && RCF<b_cost)
                    bestVC=RVC;
                    b_cost=RCF;
                end
            else
                counter(r_index,1)=counter(r_index,1)+1;
            end
            gen=gen+1;
        end
    end
    for i=1:SN
        if counter(i,1)>=limit
            rfvc=change_sol(VC_Set{i,1},cap,demands,a,b,L,s,dist,cusnum,D,width,toRemove);
            VC_Set{i,1}=deal_VC(rfvc);
            VC_Obj(i,1)=size(VC_Set{i,1},1);
            VC_Obj(i,2)=costFuction(VC_Set{i,1},a,b,s,L,dist,demands,cap,alph,belta);
            VC_Obj(i,3)=1/(VC_Obj(i,1)+atan(VC_Obj(i,2))/(pi/2));
            counter(i,:)=0;
        end
    end
    bestCost=[bestCost;b_cost];
    [cost,NV,TD,vio_NV,vio_cus]=statistic(bestVC,a,b,s,L,dist,demands,cap,alph,belta);
    disp(['第',num2str(iter),'代全局最优解总成本为：',num2str(cost),'，车辆使用数目为：',num2str(NV),...
        '，行驶总距离为：',num2str(TD),'，违反约束路径数目为：',num2str(vio_NV),'，违反约束顾客数目为：',num2str(vio_cus)]);
    iter=iter+1;
    if gen>=200000
        break;
    end
end
bestVC=deal_VC(bestVC);
end