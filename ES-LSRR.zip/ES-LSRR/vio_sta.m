%
%
function [vio_NV,vio_cus]=vio_sta(VC,cap,demands,a,b,L,s,dist)
NV=size(VC,1);
vio_NV=0;
vio_cus=0;
for i=1:NV
    route=VC{i,1};
    flagR=judge_route(route,cap,demands,a,b,L,s,dist);
    if flagR==0
        vio_cus=vio_cus+numel(route);
        vio_NV=vio_NV+1;
    end
end
end