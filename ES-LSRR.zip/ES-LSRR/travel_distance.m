%
%
function [sumTD,everyTD]=travel_distance(VC,dist)
n=size(VC,1);
everyTD=zeros(n,1);
for i=1:n
    route=VC{i};
    if ~isempty(route)
        everyTD(i)=part_length(route,dist);
    end
end
sumTD=sum(everyTD);
end
