%
%
function Nik=next_point_set(route_k,cusnum,VC,cap,demands,a,b,L,s,dist,unVisit,uvNum)
if ~isempty(route_k)
    route=VC{end,1};
    lr=length(route);
    preroute=zeros(1,lr+1);
    preroute(1:lr)=route;
    Nik=zeros(uvNum,1);
    for i=1:uvNum
        preroute(end)=unVisit(i);
        flag=JudgeRoute(preroute,cap,demands,a,b,L,s,dist);
        if flag==1
            Nik(i)=unVisit(i);
        end
    end
    Nik(Nik==0)=[];
else
    Nik=1:cusnum;
end
end