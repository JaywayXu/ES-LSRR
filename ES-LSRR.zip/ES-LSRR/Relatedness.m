%
%
function Rij=Relatedness(i,j,dist,VC,width,demands)
n=size(dist,1)-1;
NV=size(VC,1);
d=dist(i+1,j+1);
[md,mindex]=max((dist(i+1,2:end)));
c=d/md;
V=1;
for k=1:NV
    route=VC{k};
    findi=find(route==i,1,'first');
    findj=find(route==j,1,'first');
    if ~isempty(findi)&&~isempty(findj)
        V=0;
        break;
    end
end
Rij=1/(c+V);
end