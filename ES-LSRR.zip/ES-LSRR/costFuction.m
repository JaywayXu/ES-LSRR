%
%      
function [cost,TD,q,w]=costFuction(VC,a,b,s,L,dist,demands,cap,alph,belta)
NV=size(VC,1);
TD=travel_distance(VC,dist);
q=violateLoad(VC,demands,cap);
w=violateTW(VC,a,b,s,L,dist);
cost=TD+alph*q+belta*w;
end