%
%
function Route=re_encode(VC)
NV=size(VC,1);
Route=[];
for i=1:NV
    if i==1
        Route=[0,VC{i},0];
    else
        Route=[Route,VC{i},0];
    end
end

