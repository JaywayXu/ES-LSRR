%
%
function S=greedy(dist,VC)
NV=size(VC,1);
S=[];
for i=1:NV
    route=VC{i};
    num=length(route);
    for j=1:num
        r_route=route;
        r_route(j)=[];
        cost=part_length(route,dist)-part_length(r_route,dist);
        S=[S;i j route(j) cost];
    end
end
S=sortrows(S, -4);
end