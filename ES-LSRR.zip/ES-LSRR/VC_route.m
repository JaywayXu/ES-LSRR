%
%
function [route,r_index]=VC_route(VC)
NV=size(VC,1);
nr=zeros(NV,1);
for i=1:NV
    r=VC{i,1};
    nr(i,1)=numel(r);
end
[~,r_index]=min(nr);
route=VC{r_index,1};
end

