%
%      
function [FVC,vehicles_used]=deal_VC(VC)
vecnum=size(VC,1);                  
FVC={};                             
count=1;                           	
for i=1:vecnum
    par_seq=VC{i};                  
    if ~isempty(par_seq)                        
        FVC{count}=par_seq;
        count=count+1;
    end
end
FVC=FVC';       
vehicles_used=size(FVC,1);       
end