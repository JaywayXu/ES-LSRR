%
%
function VC=re_decode(route_k)
cusnum=size(route_k,2);
VC=cell(cusnum,1);
count=0;
preroute=[];
for i=1:cusnum
    if route_k(1,i)==0
        if ~isempty(preroute)
            VC{count,1}=preroute;
            count=count+1;
            preroute=[];
        else
            count=count+1;
        end
    else
        preroute=[preroute,route_k(1,i)];
    end
    VC=deal_VC(VC);
end
end