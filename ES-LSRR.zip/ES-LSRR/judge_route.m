%
%
function flagR=judge_route(route,cap,demands,a,b,L,s,dist)
flagR=1;
lr=numel(route);
Ld=leave_load(route,demands);
if Ld<=cap
    [bs,back]=begin_s(route,a,s,dist);
    if back<=L
        for i=1:lr
            if bs(i)>b(route(i))
                flagR=0;
                break;
            end
        end
    else
        flagR=0;
    end
else
    flagR=0;
end
end