%
%
function [RVC,RCF]=loc2(VC,cap,demands,a,b,L,s,dist,width,alph,belta,cusnum,toRemove,D)
[removed,rfvc]=Remove(cusnum,toRemove,D,dist,VC,width,demands);
while ~isempty(removed)
    [fv,fviv,fvip,fvC]=regret_inserting(removed,rfvc,L,a,b,s,dist,demands,cap);
    removed(removed==fv)=[];
    [rfvc,~]=insert(fv,fviv,fvip,fvC,rfvc,dist);
end
RVC=deal_VC(rfvc);
RCF=costFuction(RVC,a,b,s,L,dist,demands,cap,alph,belta);
end